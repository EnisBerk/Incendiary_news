﻿#-*- coding: utf-8 -*-

from . import Suffix

S1 = Suffix("-lU", "lı|li|lu|lü", None, True)

VALUES = (S1, )